<?php
/**
* 2007-2023 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2023 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
class NiubizValidationModuleFrontController extends ModuleFrontController
{
    /**
     * This class should be use by your Instant Payment
     * Notification system to validate the order remotely
     */
    public function postProcess()
    {
        if ($this->module->active == false) {
            die;
        }

        $nbz_error = base64_decode(Tools::getValue('nbz_error'));

        $cart = Context::getContext()->cart;
        $customer = Context::getContext()->customer;

        if (!Validate::isLoadedObject($cart) || !Validate::isLoadedObject($customer)) {
            Tools::redirect($this->context->link->getPageLink('order', true));
        }

        $amount = number_format($cart->getOrderTotal(true, Cart::BOTH), 2, '.', '');
        $securityKey = $this->module->securityKey();
        $sessionToken = $securityKey ? $this->module->createToken($amount, $securityKey) : false;

        if (!$securityKey || !$sessionToken) {
            $this->context->smarty->assign(array(
                'nbz_error' => $this->module->trans('No se pudo iniciar el pago con Niubiz. Por favor intente nuevamente o elija otro medio de pago.', array(), 'Modules.Niubiz.Validation'),
                'nbz_debug' => false,
                'var' => array(),
                'logo' => Configuration::get('NBZ_LOGO'),
                'linkActionReturn' => '',
                'nbz_dump' => '',
            ));
            $this->setTemplate('module:niubiz/views/templates/front/error.tpl');
            $this->errors[] = $this->module->trans('No se pudo iniciar el pago con Niubiz.', array(), 'Modules.Niubiz.Validation');
            return;
        }

        $this->module->setSecurityCookie($cart->id, $securityKey);
        $userTokenId = $this->module->userTokenId();

        $session = array();
        $session['id_cart'] = (int)$cart->id;
        $session['id_customer'] = (int)$customer->id;
        $session['sessiontoken'] = pSQL($sessionToken);
        $session['sessionkey'] = pSQL($userTokenId);

        Db::getInstance()->insert('niubiz_session', $session);
        
        $variables = array(
            'userTokenId' => $userTokenId,
            'sessionToken' => $sessionToken,
            'merchantId' => $this->module->merchantid,
            'urlScript' => $this->module->urlScript,
            'numOrden' => (int)$cart->id,
            'monto' => $amount,
            'firstname' => $customer->firstname,
            'lastname' => $customer->lastname,
            'email' => $customer->email,
        );
        
        $params_encoded = base64_encode($cart->id.'|'.$customer->secure_key);
        
        $linkActionReturn = $this->context->link->getModuleLink($this->module->name, 'return', ['nbzheader' => $params_encoded], true);

        $this->context->smarty->assign(array(
            'logo' => Configuration::get('NBZ_LOGO'),
            'nbz_error' => $nbz_error,
            'nbz_debug' => (bool) Configuration::get('NBZ_DEBUG'),
            'psVersion' => $this->module->psVersion,
            'var' => $variables,
            'linkActionReturn' => $linkActionReturn,
            // Smarty 4 (PrestaShop 9) no longer allows arbitrary PHP functions as modifiers ({$var|print_r:true}).
            'nbz_dump' => (bool) Configuration::get('NBZ_DEBUG') ? print_r($variables, true).'linkReturn='.$linkActionReturn : '',
        ));

        $this->setTemplate('module:niubiz/views/templates/front/validation.tpl');
    }
}